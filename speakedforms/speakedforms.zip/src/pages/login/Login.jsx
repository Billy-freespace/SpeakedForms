import React from "react";

const Login = () =>{
    return(
        <div>
            <p>Login</p>
        </div>
    )
}

export default Login;