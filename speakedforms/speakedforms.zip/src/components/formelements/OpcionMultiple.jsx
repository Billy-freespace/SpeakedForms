import React from "react";
import { useState } from "react";
import { Accordion, AccordionSummary, FormControlLabel, Typography } from "@mui/material";



function OpcionMultiple () { 

    const [preguntas, setPreguntas] = useState(
        [{preguntaText: "Capital de Perú:", 
          preguntaTipo: "radio",
          opciones: [
            {optionText: "Paris"},
            {optionText: "Lima"},
            {optionText: "Washington DC"},
            {optionText: "La Paz"},
          ],
            open: true,
            required: false}]
    )

    function preguntasUI(){
        return preguntas.map((preg,i)=>{
            <div>
            <Accordion expanded={preguntas[i].open} className={preguntas[i].open ? 'add border' : ""}>
                <AccordionSummary aria-controls="panel1a-content" id="panel1a-content" elevation={1} style={{width:'100%'}}>
                    {preguntas[i].open ? (
                        <div className="guardar_preguntas">
                            <Typography>{i+1}. {preguntas[i].preguntaText}</Typography>
                            {preg.opciones.map((op,j)=>{
                                <div key={j}>
                                    <div>
                                        <FormControlLabel disabled control={<input type={preg.preguntaTipo}/>} label={
                                            <Typography>{preg.opciones[j].optionText}
                                            </Typography>
                                        }/>
                                    </div>
                                </div>
                            })}
                        </div>
                    ):""}
                </AccordionSummary>
            </Accordion>
            </div>
        })
    }

    return(
        <div>
            {preguntasUI()}
        </div>
    )
}

export default OpcionMultiple;